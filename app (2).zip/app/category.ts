export interface Category{
    catId: 0,
    categoryName: string
  }