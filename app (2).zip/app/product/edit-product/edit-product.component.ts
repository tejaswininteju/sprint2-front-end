import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  editForm: FormGroup;
  
  constructor(private productService: ProductService, 
    private activatedRoute: ActivatedRoute, 
    private router: Router) {
      this.editForm = new FormGroup({
        productId: new FormControl(),
        productName: new FormControl('', [Validators.required,Validators.minLength(3),Validators.maxLength(15)]), //array of validations
        price: new FormControl(),
        color: new FormControl(),
        dimension: new FormControl(),
        specification: new FormControl(),
        manufacturer: new FormControl(),
        quantity: new FormControl(),
        productImageUrl: new FormControl(),
        category: new FormGroup({
          catId: new FormControl(),
          categoryName: new FormControl()
        })
      });
    }

  ngOnInit(): void {
    let productId: any=this.activatedRoute.snapshot.paramMap.get('prodId');
     this.productService.getProduct(productId).subscribe((response) => {
      this.editForm.setValue(response);
      console.log(response);
      console.log(this.editForm.value.category);
     });
  }

  editProduct() {
    console.log(this.editForm);
    console.log(this.editForm.value);
    this.productService.updateProduct(this.editForm.value).subscribe((response) => {
      console.log(response);
      this.router.navigate(['list-of-products']);
    });
    
  }

}
