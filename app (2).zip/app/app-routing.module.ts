import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cartdetails/cart/cart.component';

import { AddProductComponent } from './product/add-product/add-product.component';
import { EditProductComponent } from './product/edit-product/edit-product.component';
import { ListOfProductsComponent } from './product/list-of-products/list-of-products.component';

import { LoginComponent } from './user/login/login.component';
import { LogoutComponent } from './user/logout/logout.component';
import { RegisterComponent } from './user/register/register.component';

const routes: Routes = [
  {
    path: 'authenticate', component : LoginComponent
  },
  {
    path: 'register', component : RegisterComponent
  },
  {
    path: 'logout', component : LogoutComponent
  },
  // {
  //   path :'admin', component : AdminComponent
  // },
  {
    path: 'list-of-products/:username', component : ListOfProductsComponent
  },
  {
    path: 'edit-product/:prodId', component : EditProductComponent
  }, 
  {
    path: 'add-product', component : AddProductComponent
  }, 
  {
    path: 'cart', component : CartComponent
  },
  {
    path: 'list-of-products', component : ListOfProductsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
