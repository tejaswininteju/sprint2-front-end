export interface Admin{
    username: string;
    password: string;
    role: string;
}