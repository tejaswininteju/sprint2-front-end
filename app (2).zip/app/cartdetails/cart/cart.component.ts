import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '.';
import { CartService } from '../cart.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  // cartList: Cart[]=[];
  addCartData = {
        cartId: 0, 
        addingDate: '',
        product: [{
          productId: 0,
          productName: '',
          price: 0,
          color: '',
          dimension: '',
          specification: '',
          manufacturer: '',
          quantity: 0,
          productImageUrl: ''
        }]
        // customer: {
        //   customerId: 0
        // }
  }
  totalSum: number = 0;

  constructor(private cartService: CartService, private router: Router ) { }

  ngOnInit(): void {
  // this.cartService.getCartItems().subscribe(response =>{
  //   this.cartList = response.oblist;
  //   // this.cartList.forEach(value =>{
  //   //   this.totalSum = this.totalSum+(value.quantity*value.price);
  //   // });
  // });
  }

  addingToCart(cartId: any){
    this.cartService.addToCart(cartId.value).subscribe(response =>{
      // this.cartList.forEach(value =>{
      //   this.totalSum = this.totalSum + (value.price);
      // })
    })
  }

  
  // addToCart(cartId: any) {
  //   this.cartService.addToCart(cartId).subscribe(response => {
  //     console.log(response);
  //   })
  // }
 

  


}
